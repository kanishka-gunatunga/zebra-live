<div class="p-lg-3 p-xl-3 p-md-3 p-1">
                                        <div class="comparing-head p-1 py-0">
                                            <div class="comparing-head-section">
                                                <p class="name">{{$compare_details->display_name}}</p>
                                            </div>
                                            <div class="comparing-head-section">
                                                <p class="email">{{$compare_details->email}}</p>
                                            </div>
                                        </div>



                                        <div class="col-12 scrollable-campare">
                                            <div class="row mb-5 gx-3 gy-3">

                                                <div class="col-12 mt-5 d-flex justify-content-center p-2">
                                                    <img src="{{ asset('assets/images/patterns.png') }}"
                                                        class="patterns-img">
                                                </div>

                                                <div class="row ps-4 gap-0">


                                                    <div class="col-12 px-0">
                                                        <div class="d-flex flex-column p-3 px-0 justify-content-center">
                                                            <div class="col-12 px-0">
                                                                <h5 class="explaining-title">Realist</h5>
                                                                <p class="explaining">
                                                                    Lorem ipsum dolor sit amet consectetur. Mi ornare
                                                                    justo
                                                                    lacus felis. In tortor ultrices morbi sed proin
                                                                    lectus.
                                                                    Semper vel commodo a massa velit faucibus pulvinar
                                                                    lacus. Mauris amet neque a nec sed fames.
                                                                    Cursus proin bibendum nulla tempus. Eu non laoreet
                                                                    non
                                                                    arcu facilisis sollicitudin laoreet sed.
                                                                    Non eget nulla tellus aliquam sodales. Volutpat nunc
                                                                    feugiat quam ipsum rutrum ornare.
                                                                    Non neque fringilla lorem pellentesque mauris.
                                                                    Ornare
                                                                    aenean placerat venenatis congue amet amet.
                                                                    Dignissim in faucibus vitae enim sit integer blandit
                                                                    odio a.
                                                                    Aliquet ullamcorper nec condimentum gravida
                                                                    imperdiet
                                                                    sit interdum morbi. Augue integer vel orci tortor.
                                                                    Viverra tellus lacus ipsum in integer pellentesque
                                                                    id
                                                                    pretium. Ut aliquam diam a viverra sit.
                                                                    Metus aliquam vulputate diam quisque volutpat
                                                                    suspendisse vitae malesuada.
                                                                    Ullamcorper adipiscing velit tortor venenatis
                                                                    feugiat
                                                                    orci placerat faucibus sed.
                                                                </p>
                                                            </div>

                                                            <div class="col-12">
                                                                <h5 class="explaining-title">Strategist</h5>
                                                                <p class="explaining">
                                                                    Lorem ipsum dolor sit amet consectetur. Mi ornare
                                                                    justo
                                                                    lacus felis. In tortor ultrices morbi sed proin
                                                                    lectus.
                                                                    Semper vel commodo a massa velit faucibus pulvinar
                                                                    lacus. Mauris amet neque a nec sed fames.
                                                                    Cursus proin bibendum nulla tempus. Eu non laoreet
                                                                    non
                                                                    arcu facilisis sollicitudin laoreet sed.
                                                                    Non eget nulla tellus aliquam sodales. Volutpat nunc
                                                                    feugiat quam ipsum rutrum ornare.
                                                                    Non neque fringilla lorem pellentesque mauris.
                                                                    Ornare
                                                                    aenean placerat venenatis congue amet amet.
                                                                    Dignissim in faucibus vitae enim sit integer blandit
                                                                    odio a.
                                                                    Aliquet ullamcorper nec condimentum gravida
                                                                    imperdiet
                                                                    sit interdum morbi. Augue integer vel orci tortor.
                                                                    Viverra tellus lacus ipsum in integer pellentesque
                                                                    id
                                                                    pretium. Ut aliquam diam a viverra sit.
                                                                    Metus aliquam vulputate diam quisque volutpat
                                                                    suspendisse vitae malesuada.
                                                                    Ullamcorper adipiscing velit tortor venenatis
                                                                    feugiat
                                                                    orci placerat faucibus sed.
                                                                </p>
                                                            </div>

                                                            <div class="col-12">
                                                                <h5 class="explaining-title">Innovator</h5>
                                                                <p class="explaining">
                                                                    Lorem ipsum dolor sit amet consectetur. Mi ornare
                                                                    justo
                                                                    lacus felis. In tortor ultrices morbi sed proin
                                                                    lectus.
                                                                    Semper vel commodo a massa velit faucibus pulvinar
                                                                    lacus. Mauris amet neque a nec sed fames.
                                                                    Cursus proin bibendum nulla tempus. Eu non laoreet
                                                                    non
                                                                    arcu facilisis sollicitudin laoreet sed.
                                                                    Non eget nulla tellus aliquam sodales. Volutpat nunc
                                                                    feugiat quam ipsum rutrum ornare.
                                                                    Non neque fringilla lorem pellentesque mauris.
                                                                    Ornare
                                                                    aenean placerat venenatis congue amet amet.
                                                                    Dignissim in faucibus vitae enim sit integer blandit
                                                                    odio a.
                                                                    Aliquet ullamcorper nec condimentum gravida
                                                                    imperdiet
                                                                    sit interdum morbi. Augue integer vel orci tortor.
                                                                    Viverra tellus lacus ipsum in integer pellentesque
                                                                    id
                                                                    pretium. Ut aliquam diam a viverra sit.
                                                                    Metus aliquam vulputate diam quisque volutpat
                                                                    suspendisse vitae malesuada.
                                                                    Ullamcorper adipiscing velit tortor venenatis
                                                                    feugiat
                                                                    orci placerat faucibus sed.
                                                                </p>
                                                            </div>

                                                            <div class="col-12">
                                                                <h5 class="explaining-title">Empath</h5>
                                                                <p class="explaining">
                                                                    Lorem ipsum dolor sit amet consectetur. Mi ornare
                                                                    justo
                                                                    lacus felis. In tortor ultrices morbi sed proin
                                                                    lectus.
                                                                    Semper vel commodo a massa velit faucibus pulvinar
                                                                    lacus. Mauris amet neque a nec sed fames.
                                                                    Cursus proin bibendum nulla tempus. Eu non laoreet
                                                                    non
                                                                    arcu facilisis sollicitudin laoreet sed.
                                                                    Non eget nulla tellus aliquam sodales. Volutpat nunc
                                                                    feugiat quam ipsum rutrum ornare.
                                                                    Non neque fringilla lorem pellentesque mauris.
                                                                    Ornare
                                                                    aenean placerat venenatis congue amet amet.
                                                                    Dignissim in faucibus vitae enim sit integer blandit
                                                                    odio a.
                                                                    Aliquet ullamcorper nec condimentum gravida
                                                                    imperdiet
                                                                    sit interdum morbi. Augue integer vel orci tortor.
                                                                    Viverra tellus lacus ipsum in integer pellentesque
                                                                    id
                                                                    pretium. Ut aliquam diam a viverra sit.
                                                                    Metus aliquam vulputate diam quisque volutpat
                                                                    suspendisse vitae malesuada.
                                                                    Ullamcorper adipiscing velit tortor venenatis
                                                                    feugiat
                                                                    orci placerat faucibus sed.
                                                                </p>
                                                            </div>

                                                            <div class="col-12">
                                                                <h5 class="explaining-title">Organizer</h5>
                                                                <p class="explaining">
                                                                    Lorem ipsum dolor sit amet consectetur. Mi ornare
                                                                    justo
                                                                    lacus felis. In tortor ultrices morbi sed proin
                                                                    lectus.
                                                                    Semper vel commodo a massa velit faucibus pulvinar
                                                                    lacus. Mauris amet neque a nec sed fames.
                                                                    Cursus proin bibendum nulla tempus. Eu non laoreet
                                                                    non
                                                                    arcu facilisis sollicitudin laoreet sed.
                                                                    Non eget nulla tellus aliquam sodales. Volutpat nunc
                                                                    feugiat quam ipsum rutrum ornare.
                                                                    Non neque fringilla lorem pellentesque mauris.
                                                                    Ornare
                                                                    aenean placerat venenatis congue amet amet.
                                                                    Dignissim in faucibus vitae enim sit integer blandit
                                                                    odio a.
                                                                    Aliquet ullamcorper nec condimentum gravida
                                                                    imperdiet
                                                                    sit interdum morbi. Augue integer vel orci tortor.
                                                                    Viverra tellus lacus ipsum in integer pellentesque
                                                                    id
                                                                    pretium. Ut aliquam diam a viverra sit.
                                                                    Metus aliquam vulputate diam quisque volutpat
                                                                    suspendisse vitae malesuada.
                                                                    Ullamcorper adipiscing velit tortor venenatis
                                                                    feugiat
                                                                    orci placerat faucibus sed.
                                                                </p>
                                                            </div>

                                                            <div class="col-12">
                                                                <h5 class="explaining-title">Analyst
                                                                </h5>
                                                                <p class="explaining">
                                                                    Lorem ipsum dolor sit amet consectetur. Mi ornare
                                                                    justo
                                                                    lacus felis. In tortor ultrices morbi sed proin
                                                                    lectus.
                                                                    Semper vel commodo a massa velit faucibus pulvinar
                                                                    lacus. Mauris amet neque a nec sed fames.
                                                                    Cursus proin bibendum nulla tempus. Eu non laoreet
                                                                    non
                                                                    arcu facilisis sollicitudin laoreet sed.
                                                                    Non eget nulla tellus aliquam sodales. Volutpat nunc
                                                                    feugiat quam ipsum rutrum ornare.
                                                                    Non neque fringilla lorem pellentesque mauris.
                                                                    Ornare
                                                                    aenean placerat venenatis congue amet amet.
                                                                    Dignissim in faucibus vitae enim sit integer blandit
                                                                    odio a.
                                                                    Aliquet ullamcorper nec condimentum gravida
                                                                    imperdiet
                                                                    sit interdum morbi. Augue integer vel orci tortor.
                                                                    Viverra tellus lacus ipsum in integer pellentesque
                                                                    id
                                                                    pretium. Ut aliquam diam a viverra sit.
                                                                    Metus aliquam vulputate diam quisque volutpat
                                                                    suspendisse vitae malesuada.
                                                                    Ullamcorper adipiscing velit tortor venenatis
                                                                    feugiat
                                                                    orci placerat faucibus sed.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>
                                        </div>
                                    </div>